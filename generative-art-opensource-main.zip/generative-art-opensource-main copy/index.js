const fs = require("fs");
const { createCanvas, loadImage } = require("canvas");
const {
  layers,
  width,
  height,
  description,
  baseImageUri,
  editionSize,
  startEditionFrom,
  rarityWeights,
} = require("./input/config.js");
const console = require("console");
const canvas = createCanvas(width, height);
const ctx = canvas.getContext("2d");

// hier word de gemaakte afbeeldign opgeslagen in de output folder met het bijgaande nummer.
const saveImage = (_editionCount) => {
  fs.writeFileSync(
    `./output/${_editionCount}.png`,
    canvas.toBuffer("image/png")
  );
};

// Hier word het nummer signature toegevoegd aan elke afbeelding
const signImage = (_sig) => {
  ctx.fillStyle = "#000000";
  ctx.font = "bold 30pt Courier";
  ctx.textBaseline = "top";
  ctx.textAlign = "left";
  ctx.fillText(_sig, 40, 40);
};

// Hier word een random kleur hue toegevoegd aan de code
const genColor = () => {
  let hue = Math.floor(Math.random() * 360);
  let pastel = `hsl(${hue}, 100%, 85%)`;
  return pastel;
};

const drawBackground = () => {
  ctx.fillStyle = genColor();
  ctx.fillRect(0, 0, width, height);
};

// Hier word de meta beschrijving toegevoegd aan het bestand
const generateMetadata = (_dna, _edition, _attributesList) => {
  let dateTime = Date.now();
  let tempMetadata = {
    dna: _dna.join(""),
    name: `#${_edition}`,
    description: description,
    image: `${baseImageUri}/${_edition}`,
    edition: _edition,
    date: dateTime,
    attributes: _attributesList,
  };
  return tempMetadata;
};

// voorbereiden van de atributten voor elk elements zodat dit gebruikt kan worden als metadata
const getAttributeForElement = (_element) => {
  let selectedElement = _element.layer.selectedElement;
  let attribute = {
    name: selectedElement.name,
    rarity: selectedElement.rarity,
  };
  return attribute;
};

// laad de afbeeldingen vanuit de verschillende laag mappen in
// En zet deze bestanden om zodat deze gebruikt kunnen worden op het canvas
const loadLayerImg = async (_layer) => {
  return new Promise(async (resolve) => {
    const image = await loadImage(`${_layer.selectedElement.path}`);
    resolve({ layer: _layer, loadedImage: image });
  });
};

const drawElement = (_element) => {
  ctx.drawImage(
    _element.loadedImage,
    _element.layer.position.x,
    _element.layer.position.y,
    _element.layer.size.width,
    _element.layer.size.height
  );
};

// Hier worden de lagen voorbereid op het maken van een DNA en het plaatsen op de canvas
const constructLayerToDna = (_dna = [], _layers = [], _rarity) => {
  let mappedDnaToLayers = _layers.map((layer, index) => {
    let selectedElement = layer.elements.find(element => element.id === _dna[index]);
    return {
      location: layer.location,
      position: layer.position,
      size: layer.size,
      selectedElement: {...selectedElement, rarity: _rarity },
    };
  });
  return mappedDnaToLayers;
};

// Hier word met de DNA gecheckt of er een dubplicaat aanwezig is
// Als dit zo is word er een nieuwe afbeelding gemaakt
const isDnaUnique = (_DnaList = [], _dna = []) => {
  let foundDna = _DnaList.find((i) => i.join("") === _dna.join(""));
  return foundDna == undefined ? true : false;
};

const getRandomRarity = (_rarityOptions) => {
  let randomPercent = Math.random() * 100;
  let percentCount = 0;

  for (let i = 0; i <= _rarityOptions.length; i++) {
    percentCount += _rarityOptions[i].percent;
    if (percentCount >= randomPercent) {
      console.log(`use random rarity ${_rarityOptions[i].id}`)
      return _rarityOptions[i].id;
    }
  }
  return _rarityOptions[0].id;
}

// een DNA word gegenereerd op basis van de lagen en de rarity die opgegeven is
const createDna = (_layers, _rarity) => {
  let randNum = [];
  let _rarityWeight = rarityWeights.find(rw => rw.value === _rarity);
  _layers.forEach((layer) => {
    let num = Math.floor(Math.random() * layer.elementIdsForRarity[_rarity].length);
    if (_rarityWeight && _rarityWeight.layerPercent[layer.id]) {

      let _rarityForLayer = getRandomRarity(_rarityWeight.layerPercent[layer.id]);
      num = Math.floor(Math.random() * layer.elementIdsForRarity[_rarityForLayer].length);
      randNum.push(layer.elementIdsForRarity[_rarityForLayer][num]);
    } else {
      randNum.push(layer.elementIdsForRarity[_rarity][num]);
    }
  });
  return randNum;
};

// Hier worden de raritys voor elke editie in opgeslagen
let rarityForEdition;
// hier word de rarity gemaakt
const getRarity = (_editionCount) => {
  if (!rarityForEdition) {
    // Een array zodat het bij elke iteratie word gedaan
    rarityForEdition = [];
    rarityWeights.forEach((rarityWeight) => {
      for (let i = rarityWeight.from; i <= rarityWeight.to; i++) {
        rarityForEdition.push(rarityWeight.value);
      }
    });
  }
  return rarityForEdition[editionSize - _editionCount];
};

const writeMetaData = (_data) => {
  fs.writeFileSync("./output/_metadata.json", _data);
};


let dnaListByRarity = {};
// Bewaard alle metadata voor de NFts
let metadataList = [];
const startCreating = async () => {
  console.log('##################');
  console.log('# Generative Art');
  console.log('# - Create your NFT collection');
  console.log('##################');

  console.log();
  console.log('start creating NFTs.')

  // reset de metadata voor de volgende run
  writeMetaData("");

  rarityWeights.forEach((rarityWeight) => {
    dnaListByRarity[rarityWeight.value] = [];
  });

  // Het maken van de NFT met startEditionFrom en editionSize
  let editionCount = startEditionFrom;
  while (editionCount <= editionSize) {
    console.log('-----------------')
    console.log('creating NFT %d of %d', editionCount, editionSize);

    // Inladen van de rarity vanuit de config
    let rarity = getRarity(editionCount);
    console.log('- rarity: ' + rarity);

    // Berekenen van de unieke DNA's aan de hand van de lagen
    let newDna = createDna(layers, rarity);
    while (!isDnaUnique(dnaListByRarity[rarity], newDna)) {
      // openieuw berekenen als er een nieuwe dna gemaakt moet worden
      console.log('found duplicate DNA ' + newDna.join('-') + ', recalculate...');
      newDna = createDna(layers, rarity);
    }
    console.log('- dna: ' + newDna.join('-'));

    // Voorbereiding voor het maken van de canvas
    let results = constructLayerToDna(newDna, layers, rarity);
    let loadedElements = [];

    // Alle afbeeldingen inladen
    results.forEach((layer) => {
      loadedElements.push(loadLayerImg(layer));
    });

    // Wachten totdat alles is ingeladen voordat het verder gaat met het programma
    await Promise.all(loadedElements).then((elementArray) => {
      // Maakt lege afbeelding
      ctx.clearRect(0, 0, width, height);
      drawBackground();
      // Informatie opslaan zodat het kan worden opgeslagen als meta
      let attributesList = [];
      // teken elke laag
      elementArray.forEach((element) => {
        drawElement(element);
        attributesList.push(getAttributeForElement(element));
      });
      // toevoegen van ee signature nummering
      signImage(`#${editionCount}`);
      // opslaan naar de output map
      saveImage(editionCount);
      let nftMetadata = generateMetadata(newDna, editionCount, attributesList);
      metadataList.push(nftMetadata)
      console.log('- metadata: ' + JSON.stringify(nftMetadata));
      console.log('- edition ' + editionCount + ' created.');
      console.log();
    });
    dnaListByRarity[rarity].push(newDna);
    editionCount++;
  }
  writeMetaData(JSON.stringify(metadataList));
};

// start het programma.
startCreating();